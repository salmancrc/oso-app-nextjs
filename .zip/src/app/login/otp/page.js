import OTP from '@/pages/login/Otp'
import React from 'react'
const page = () => {
  return <OTP />
}
export function generateMetadata(params) {
  return {
    title: "OTP | OSO",
    description: "OTP Page"
  }
}

export default page
