'use client'
import Login from '@/pages/login/Index'
import React from 'react'

const page = () => {
    return <Login />
}

export default page
