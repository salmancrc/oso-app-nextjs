import FirstSearch from '@/pages/search/UI/FirstSearch'
import React from 'react'

const page = () => {
  return <FirstSearch />
}

export default page